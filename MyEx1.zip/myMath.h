float add (float,float);
float sub (float,float);
double mul (double,int);
double div (double,int);

double Exponent(int);
double Power(double,int);
