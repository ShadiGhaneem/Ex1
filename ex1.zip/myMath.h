float add (float,float);
float sub (float,float);
double mul (double,int);
double div (double,int);

double Exp (int);
double Pow (double,int);
